/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.policestationdatavisualization;

/**
 *
 * @author sai
 */
public class Police_Station_Data_Visualization {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
